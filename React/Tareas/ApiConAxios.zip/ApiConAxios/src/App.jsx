import React from "react";
import "./App.css";
import RandomImage from "./components/RandomImage";

function App() {
  return (
    <div className="App">
      <h1 className="title">Imagenes</h1>
      <RandomImage />
    </div>
  );
}

export default App;